#[doc = "Reader of register ADC12IV"]
pub type R = crate::R<u16, super::ADC12IV>;
#[doc = "Writer for register ADC12IV"]
pub type W = crate::W<u16, super::ADC12IV>;
#[doc = "Register ADC12IV `reset()`'s with value 0"]
impl crate::ResetValue for super::ADC12IV {
    type Type = u16;
    #[inline(always)]
    fn reset_value() -> Self::Type {
        0
    }
}
impl R {}
impl W {}
