#[doc = "Reader of register SYSJMBO1"]
pub type R = crate::R<u16, super::SYSJMBO1>;
#[doc = "Writer for register SYSJMBO1"]
pub type W = crate::W<u16, super::SYSJMBO1>;
#[doc = "Register SYSJMBO1 `reset()`'s with value 0"]
impl crate::ResetValue for super::SYSJMBO1 {
    type Type = u16;
    #[inline(always)]
    fn reset_value() -> Self::Type {
        0
    }
}
impl R {}
impl W {}
